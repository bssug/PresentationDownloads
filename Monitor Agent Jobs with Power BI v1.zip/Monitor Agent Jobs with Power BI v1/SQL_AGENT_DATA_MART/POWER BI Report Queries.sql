/*

	POWER BI Report Queries

*/

USE [SQL_AGENT_DATA_MART_V1]
GO


-- SQL Agent Status
SELECT 
	status_desc
FROM sys.dm_server_services
WHERE servicename LIKE 'SQL Server Agent%'


-- Last Refresh
SELECT MAX(RefreshDate) AS LastRefresh
FROM [dbo].[ActiveJobsRefresh]


-- SQL Agent Job Activity
SELECT *
FROM [dbo].[vActiveJobs]

