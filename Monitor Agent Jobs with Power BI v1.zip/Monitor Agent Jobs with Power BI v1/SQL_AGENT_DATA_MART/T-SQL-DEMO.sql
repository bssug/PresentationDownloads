/*
	LAUNCH SQL AGENT JOBS and VIEW POWER BI DASHBOARD

	SQL AGENT JOB BSSUG - SQL AGENT DATA MART ETL runs every minute

	SAMPLE SQL AGENT JOBS to run:
	CRM ETL
	DEMO 15-25 MINUTES
	DEMO FOR SQL AGENT DATA MART
	ONE-TWO-MINUTE-JOB
*/

USE [SQL_AGENT_DATA_MART_V1]
GO


EXEC msdb.dbo.sp_start_job @job_name = 'CRM ETL'

EXEC msdb.dbo.sp_start_job @job_name = 'DEMO 15-25 MINUTES'

EXEC msdb.dbo.sp_start_job @job_name = 'ONE-TWO-MINUTE-JOB';


-- show sysjobhistory

DECLARE @TODAY INT = FORMAT(GETDATE(), 'yyyyMMdd');
SELECT  
	h.[instance_id]
,	j.[job_id]
,	j.[name]
,	h.[step_id]					-- 0 = job outcome, > 0 job step_id outcome 
,	h.[run_date]				-- int formatted as YYYYMMDD
,	h.[run_time]				-- int start time formatted as Hours Minutes Seconds
,	h.[run_duration]			-- int formatted as Hours Minutes Seconds
,	h.[retries_attempted]
FROM msdb.dbo.sysjobhistory h
JOIN msdb.dbo.sysjobs j
ON j.[job_id] = h.[job_id]
WHERE h.[run_date] = @TODAY
AND h.[run_status] = 1		-- success
ORDER BY h.[instance_id] DESC;


-- show sysjobactivity

DECLARE 
	@SESSION_ID	INT;

SELECT
	@SESSION_ID = MAX(session_id)
FROM msdb.dbo.syssessions;

SELECT
	a.[job_id]
,	a.[start_execution_date]
,	a.[last_executed_step_id]
,	a.[last_executed_step_date]
FROM msdb.dbo.sysjobactivity a
LEFT JOIN [dbo].[ExcludeActiveJobs] e
ON e.[job_id] = a.[job_id]
WHERE a.session_id = @SESSION_ID
AND a.start_execution_date IS NOT NULL
AND stop_execution_date IS NULL
AND e.[job_id] IS NULL



-- show details on the jobs currently running

SELECT *
FROM [dbo].[vActiveJobs]


-- show details on average step duration

SELECT 
	j.[name]
,	d.*
FROM [dbo].[JobStepAverageDuration] d
JOIN [dbo].[Job] j
ON j.[job_id] = d.[job_id]
LEFT JOIN [dbo].[ExcludeActiveJobs] x
ON x.[job_id] = d.[job_id]
WHERE x.[job_id] IS NULL
ORDER BY j.[name], d.[step_id];

