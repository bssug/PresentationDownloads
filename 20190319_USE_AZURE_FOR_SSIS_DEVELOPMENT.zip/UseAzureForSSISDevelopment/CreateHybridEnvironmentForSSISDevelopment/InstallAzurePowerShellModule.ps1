﻿#  install the Azure PowerShell module

# check the PowerShell version; must be 5.x
$PSVersionTable.PSVersion

# Install; must be running as administrator
Install-Module -Name Az -AllowClobber

