﻿# Connect to Azure with a browser sign in token
Import-Module Az.Accounts
Connect-AzAccount