My Tip on Using Azure Storage and Azure SQL Database for SSIS Development
https://www.mssqltips.com/sqlservertip/5514/using-azure-storage-and-azure-sql-database-for-ssis-development/
