-- DROP DATABASE TEST
CREATE DATABASE Test;
GO

USE Test;
GO

CREATE TABLE Orders
    (
      OrderID TINYINT PRIMARY KEY
                      IDENTITY(1, 1) ,
      DateIn DATETIME NOT NULL
    );
 
INSERT  INTO Orders
        SELECT  GETDATE();
-- Now run the IDENTITY check query below 
 

-- Next insert a row with 240    
SET IDENTITY_INSERT Orders ON;
GO
INSERT  INTO Orders
        ( OrderID, DateIn )
        SELECT  240 ,
                GETDATE();
GO
SET IDENTITY_INSERT Orders OFF;
-- Run the IDENTITY check query again 


----------------------------------------------------
/* Define how close we are to the value limit
   before we start throwing up the red flag.
   The higher the value, the closer to the limit. */
DECLARE @threshold DECIMAL(3, 2) = .80;
 
/* Create a temp table */
CREATE TABLE #identityStatus
    (
      table_name VARCHAR(128) ,
      column_name VARCHAR(128) ,
      data_type VARCHAR(128) ,
      last_value BIGINT ,
      max_value BIGINT
    );
 
INSERT  INTO #identityStatus
        SELECT  T.TABLE_NAME ,
                C.COLUMN_NAME ,
                C.DATA_TYPE ,
                IDENT_CURRENT(T.TABLE_NAME) AS last_value ,
                CASE WHEN C.DATA_TYPE = 'tinyint' THEN 255
                     WHEN C.DATA_TYPE = 'smallint' THEN 32767
                     WHEN C.DATA_TYPE = 'int' THEN 2147483647
                     WHEN C.DATA_TYPE = 'bigint' THEN 9223372036854775807
                     WHEN C.DATA_TYPE IN ( 'numeric', 'decimal' )
                     THEN CAST(POWER(CAST(10 AS FLOAT),
                                     ( C.NUMERIC_PRECISION - C.NUMERIC_SCALE )) AS DECIMAL(26))
                          - 1
                END AS [max_value]
        FROM    INFORMATION_SCHEMA.COLUMNS C
                JOIN INFORMATION_SCHEMA.TABLES T ON T.TABLE_TYPE = 'BASE TABLE'
                                                    AND T.TABLE_NAME = C.TABLE_NAME
                                                    AND COLUMNPROPERTY(OBJECT_ID(T.TABLE_NAME),
                                                              C.COLUMN_NAME,
                                                              N'IsIdentity') = 1;
 
/* Retrieve our results and format it all prettily */
SELECT  table_name ,
        column_name ,
        data_type ,
        last_value ,
        CASE WHEN last_value < 0 THEN 100
             ELSE ( 1 - CAST(last_value AS FLOAT(4)) / max_value ) * 100
        END AS [percentLeft] ,
        CASE WHEN CAST(last_value AS FLOAT(4)) / max_value >= @threshold
             THEN 'warning: approaching max limit'
             ELSE 'okay'
        END AS [id_status]
FROM    #identityStatus
--Order By percentLeft, database_name;
--Order By database_name, last_value desc, id_status desc;
--Order By id_status desc;
ORDER BY percentLeft;
 
/* Clean up after ourselves */
DROP TABLE #identityStatus;
