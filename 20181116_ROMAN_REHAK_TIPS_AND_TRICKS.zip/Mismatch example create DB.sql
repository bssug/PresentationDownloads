--Data Mismatch on Where Clause
--Create a work database
CREATE DATABASE DBDataMismatch;
GO

USE DBDataMismatch;
GO

--Create a work table
CREATE TABLE tblDataMismatch
(
    ID INT IDENTITY(1, 1) PRIMARY KEY,
    Col1 VARCHAR(10)
);
GO

--Populate it with 100,000 records
DECLARE @i INT = 0;
SET NOCOUNT ON;

WHILE @i < 100000
BEGIN
    INSERT tblDataMismatch
    SELECT CAST(@i AS VARCHAR(10));

    SET @i = @i + 1;
END;

--Create a nonclustered index on col1 column
CREATE NONCLUSTERED INDEX IX_1 ON tblDataMismatch (Col1);


--Work table is ready
SELECT *
FROM tblDataMismatch;

--This query does index seek
SELECT *
FROM tblDataMismatch
WHERE Col1 = '111';

--But this one does index scan because there is a data mismatch and col1 is selected to convert
SELECT *
FROM tblDataMismatch
WHERE Col1 = 111;

--This also does index scan
DECLARE @value NVARCHAR(10) = '111';
SELECT *
FROM tblDataMismatch
WHERE Col1 = @value;

--Drop work database
USE master;
GO
DROP DATABASE DBDataMismatch;
