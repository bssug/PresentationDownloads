SELECT '"' + RTRIM(LTRIM('  Roman     ')) + '"' AS Result

SELECT '"' + TRIM('  Roman     ') + '"' AS Result

-- doesn't remove anything since space is not specified
SELECT '"' + TRIM( '$' FROM  '  $Roman Rehak$   ') + '"' AS Result;

SELECT '"' + TRIM( ' $' FROM  '  $Roman Rehak$  ') + '"' AS Result;



