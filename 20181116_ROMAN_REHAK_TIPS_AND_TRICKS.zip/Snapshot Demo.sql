/*
  -- Replace D2D database with your own to experiment with
  DROP DATABASE [D2D_Snapshot]
*/
USE [master]

CREATE DATABASE [D2D_Snapshot] ON   
( NAME = 'D2D_QA', 
    FILENAME = N'C:\temp\D2D.snp')
AS SNAPSHOT OF D2D
GO

USE D2D
GO
DELETE FROM dbo.tblRepository
GO
SELECT * FROM [dbo].tblRepository


USE D2D_Snapshot
GO
SELECT * FROM [dbo].tblRepository

USE [master]

ALTER DATABASE D2D
  SET single_user WITH ROLLBACK IMMEDIATE

RESTORE DATABASE D2D
  FROM DATABASE_SNAPSHOT = 'D2D_Snapshot'
GO
