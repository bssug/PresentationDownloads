/*
DROP TABLE dbo.Employees;
DROP TABLE dbo.Employees_Audit
*/

CREATE TABLE dbo.Employees
(
    EmployeeID INT NOT NULL IDENTITY(1, 1),
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    [Status] VARCHAR(20) NOT NULL
        DEFAULT 'Single'
);

INSERT INTO dbo.Employees
(
    FirstName,
    LastName
)
OUTPUT INSERTED.*
SELECT 'Susan',
       'Kelley';

CREATE TABLE dbo.Employees_Audit
(
    EmployeeID INT NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    [Status] VARCHAR(20) NOT NULL,
    ChangedBy VARCHAR(300) NOT NULL,
    ChangedDatetime DATETIME NOT NULL
);

UPDATE dbo.Employees
 SET LastName = 'Jones',
 Status = 'Married'
 OUTPUT DELETED.*, system_user, getdate()
 INTO dbo.Employees_Audit
 WHERE EmployeeID = 1;

SELECT * FROM dbo.Employees
SELECT * FROM dbo.Employees_Audit

-- sample code showing how to archive rows
WHILE 1 = 1
BEGIN
    DELETE FROM MainTable
    OUTPUT DELETED.*
    INTO ArchiveTable
    WHERE ID
    BETWEEN @MinID AND @MaxID;
END;
