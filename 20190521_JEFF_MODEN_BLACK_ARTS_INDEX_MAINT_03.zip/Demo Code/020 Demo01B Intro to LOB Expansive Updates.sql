--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 33                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Ensure that we're back to 9 months and a Fill Factor of 100%, like before.
--=================================================================================================
--===== This is the Demo01B file
    USE BlackArtsIM03
;
--===== Delete the rows we inserted 
DELETE FROM dbo.Demo01 
  WHERE SomeDate >= 'Oct 2019'
    AND SomeDate <  'Nov 2019'
;
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Rebuild the index with a 100% FillFactor, just to be sure.
  ALTER INDEX PK_Demo01 ON dbo.Demo01 REBUILD WITH (FILLFACTOR = 100)
;
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 34                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Add 10K rows to the Demo01 table without the Comments because, in real life,
--      Comments are usually added AFTER a (for example) Customer has a problem.
--      NO fragmentation will result on the INSERTs and pages auto-magically fill to 100%.
--=================================================================================================
--===== Add 10K rows in Oct 2019 **** WITHOUT THE COMMENTS ****
DECLARE  @StartDate DATETIME = 'Oct 2019' --Inclusive
        ,@EndDate   DATETIME = 'Nov 2019' --Exclusive
;
   WITH cte AS
(
 SELECT TOP 10000
         SomeDate   = RAND(CHECKSUM(NEWID()))
                    * DATEDIFF(dd,@StartDate,@EndDate)+@StartDate
        ,SomeAmount = CONVERT(DECIMAL(9,2),RAND(CHECKSUM(NEWID()))*100)

   FROM      sys.all_columns ac1 --Creates a "Pseudo Cursor" row source
  CROSS JOIN sys.all_columns ac2 --to replace the "loop"
)
 INSERT INTO dbo.Demo01 WITH (TABLOCK) --Required for Minimal Logging.
        (SomeDate,SomeAmount)
 SELECT SomeDate,SomeAmount
   FROM cte
  ORDER BY SomeDate --Won't sort if not needed so always include it.
 OPTION (RECOMPILE) --Undocumented assurance for Minimal Logging 
                    --especially if variables present.
;
GO
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 35                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Now, add the Comments, which are Out-of-Row, right???
--      There should be no problems, right??? Well... not quite.
--      LOB columns are NOT fixed width and going from NULL to 24 bytes causes
--      "ExpAnsive" Updates, which cause explosive fragmentation.
--      Note that we're only adding comments to every 30th row, kind of like real life.
--      This updates only 333 out of 10,000 rows (3.33% update rate).
--=================================================================================================
--===== Now add the Comments afterwards as we might do in real life.
 UPDATE dbo.Demo01
    SET Comment    = NULLIF(REPLICATE(CONVERT(
                        VARCHAR(MAX),NEWID()),ABS(CHECKSUM(NEWID())%300
                      )),'')
  WHERE SomeDate   >= 'Oct 2019'
    AND SomeDate   <  'Nov 2019'
    AND SomeID % 30 = 0 --Only rows with IDs evenly divisible by 30
;
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 38                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Cleanup from the test and REBUILD with a FillFactor of 70 (Reducing the Fill Factor)
--=================================================================================================
--===== Delete the rows we inserted 
DELETE FROM dbo.Demo01 
  WHERE SomeDate >= 'Oct 2019'
    AND SomeDate <  'Nov 2019'
;
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Rebuild the index with a FillFactor that should be able to handle the fragmentation.
  ALTER INDEX PK_Demo01 ON dbo.Demo01 REBUILD WITH (FILLFACTOR = 70)
;
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Run an Index DNA.
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 39                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Add the 10K rows (FillFactor of 70 is present in the Clustered Index)
--      without the comments.
--=================================================================================================
--===== Add 10K rows in Oct 2019 without the comments, just like we did before.
     -- The rows STILL fill to 100% because "Append Only" INSERTs always try
     -- to fill to 100%.
DECLARE  @StartDate DATETIME = 'Oct 2019' --Inclusive
        ,@EndDate   DATETIME = 'Nov 2019' --Exclusive
;
   WITH cte AS
(
 SELECT TOP 10000
         SomeDate   = RAND(CHECKSUM(NEWID()))
                    * DATEDIFF(dd,@StartDate,@EndDate)+@StartDate
        ,SomeAmount = CONVERT(DECIMAL(9,2),RAND(CHECKSUM(NEWID()))*100)

   FROM      sys.all_columns ac1 --Creates a "Pseudo Cursor" row source
  CROSS JOIN sys.all_columns ac2 --to replace the "loop"
)
 INSERT INTO dbo.Demo01 WITH (TABLOCK) --Required for Minimal Logging.
        (SomeDate,SomeAmount)
 SELECT SomeDate,SomeAmount
   FROM cte
  ORDER BY SomeDate --Won't sort if not needed so always include it.
 OPTION (RECOMPILE) --Undocumented assurance for Minimal Logging 
                    --especially if variables present.
;
GO
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Run an Index DNA.
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 40                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Add the Comments after the INSERT we did, like we did before.
--      (FillFactor of 70 is present in the Clustered Index)
--=================================================================================================
--===== Now add the Comments afterwards as we might do in real life
     -- like we did before.
     -- Because the table is "Append Only" the rows without the comments 
     -- all came in at 100% "natural" Fill Factor. These updates make all
     -- those rows grow and results in explosive fragmentation as if the
     -- whole table had a Fill Factor of 100%.
     -- The bottom line here is that reducing the Fill Factor does nothing
     -- to prevent page splits and it wastes a whole lot of memory/disk space
     -- and we'll still need to defrag after the updates.  We're worse off 
     -- that we were at 100%.
 UPDATE dbo.Demo01
    SET Comment    = NULLIF(REPLICATE(CONVERT(
                        VARCHAR(MAX),NEWID()),ABS(CHECKSUM(NEWID())%300
                      )),'')
  WHERE SomeDate   >= 'Oct 2019'
    AND SomeDate   <  'Nov 2019'
    AND SomeID % 30 = 0 --Only rows with IDs evenly divisible by 30
;
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
