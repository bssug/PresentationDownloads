--===== This is the Demo01A file

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                       Page 13                                         @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Create and populate a typical table for this problem
--      We're creating 90,000 rows of approximately 10,000 rows per months from Jan thru Sep 2019.
--=================================================================================================
--===== Make sure we're using the corrrect demo database for this presentaiton.
    USE BlackArtsIM03

--===== If the test table already exists, drop it to make rerun in SSMS easier.
     IF OBJECT_ID('dbo.Demo01') IS NOT NULL
   DROP TABLE dbo.Demo01
;
GO
--===== Create the table
 CREATE TABLE dbo.Demo01
        (
         SomeID         INT             IDENTITY(1,1)    --Fixed Width, 4 bytes
        ,SomeDate       DATETIME        NOT NULL         --Fixed Width, 8 bytes
        ,SomeAmount     DECIMAL(9,2)    NULL             --Fixed Width, 5 bytes
        ,OtherColumns   CHAR(100)       NULL DEFAULT 'X' --Represents 100 bytes of other fixed width columns
        ,Comment        VARCHAR(MAX)    NULL             --LOB (Variable Width)
        ,CONSTRAINT PK_Demo01 PRIMARY KEY CLUSTERED (SomeID)
               WITH (FILLFACTOR = 100)
        )
;
--===== Populate the table with test data (9 months with approximately 10K rows per month)
     -- (Minimally logged in BULK LOGGED/SIMPLE Recovery Models
     -- even with the Clustered Index in-place on 2008+)
     -- Comments will be anywhere from NULL to 10,764 bytes
     -- and the table will contain 9 months of data (Jan thru Sep 2019)
DECLARE  @StartDate DATETIME = 'Jan 2019' --Inclusive
        ,@EndDate   DATETIME = 'Oct 2019' --Exclusive
;
     -- Start Measuring Time and I/O
    SET STATISTICS TIME,IO ON
;
     -- Actual table population
   WITH cte AS
(
 SELECT TOP 90000
         SomeDate   = RAND(CHECKSUM(NEWID()))
                    * DATEDIFF(dd,@StartDate,@EndDate)+@StartDate
        ,SomeAmount = CONVERT(DECIMAL(9,2),RAND(CHECKSUM(NEWID()))*100)
        ,Comment    = NULLIF(REPLICATE(CONVERT(
                        VARCHAR(MAX),NEWID()),ABS(CHECKSUM(NEWID())%300
                      )),'')
   FROM      sys.all_columns ac1 --Creates a "Pseudo Cursor" row source
  CROSS JOIN sys.all_columns ac2 --to replace the "loop"
)
 INSERT INTO dbo.Demo01 WITH (TABLOCK) --Required for Minimal Logging.
        (SomeDate,SomeAmount,Comment)
 SELECT SomeDate,SomeAmount,Comment
   FROM cte
  ORDER BY SomeDate --Won't sort if not needed so always include it.
 OPTION (RECOMPILE) --Undocumented assurance for Minimal Logging 
                    --especially if variables present.
;
     -- Stop Measuring Time and I/O
    SET STATISTICS TIME,IO OFF
;
GO
--=================================================================================================
--      Examine the data
--=================================================================================================
--===== Let's see what the first 100 rows look like.
 SELECT TOP 100 *
        ,LenComment = LEN(Comment)--This was for visual verification
   FROM dbo.Demo01
  ORDER BY SomeDate
;
GO
--===== Check to see the various lengths of the Comment column
   WITH cte AS 
(
 SELECT LenComment = LEN(Comment)
   FROM dbo.Demo01
)
 SELECT LenComment, Instances = COUNT(*)
   FROM cte
  GROUP BY LenComment
  ORDER BY LenComment
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 14                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                       Page 15                                         @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Create the data for an "Index DNA" chart for the current condition of the table. (~00:50)
--      With "Copy Column Headers" enabled...
--      Copy the first result set to the first Blue cell on the spreadsheet and
--      the second result set to the second Blue cell to "see" the index fragmentation.
--      Make sure that you're in the grid mode.
--=================================================================================================
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                       Page 16                                         @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Do an index REBUILD and sample the Index DNA again.
--=================================================================================================
--===== Rebuild the index to see if we can help the page density (~ 5-7 Seconds)
        CHECKPOINT;
    SET STATISTICS TIME,IO ON;
  ALTER INDEX PK_Demo01 ON dbo.Demo01 REBUILD;
    SET STATISTICS TIME,IO OFF
;
--Check the disk usage again.  At 1000/100 with LDF still mostly unused.
--MDF grew significantly because a rebuild replaces the table before dropping the original.
--For "monster" tables, use the "move out, move back in" trick to prevent such growth.
GO
--===== Run an Index DNA to see if REBUILD helped
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--=================================================================================================
--      Do an index REORGANIZE and sample the Index DNA again.
--=================================================================================================
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== REORGANIZE the index to see if we can help the page density (~27 seconds)
        CHECKPOINT;
    SET STATISTICS TIME,IO ON;
  ALTER INDEX PK_Demo01 ON dbo.Demo01 REORGANIZE;
    SET STATISTICS TIME,IO OFF;
--Check the disk usage again. LDF Grew to 600MB even though there was NO
--Logical Fragmentation. Not exactly "less resource intensive".

--===== Run an Index DNA to see if REORGANIZE helped
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 18                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Run the report with the original In-Row mess.
--      Then look at the "Messages" tab to see how many pages were read.
--=================================================================================================
--===== Clear the "guns"
        CHECKPOINT;
   DBCC FREEPROCCACHE;
   DBCC DROPCLEANBUFFERS
;
GO
--===== Turn the timers on, run the report, turn the timers off.
    SET STATISTICS TIME,IO ON;
 SELECT  [YYYY-MM]  = CASE GROUPING(DATEDIFF(mm,0,SomeDate))
                      WHEN 0 THEN CONVERT(CHAR(7),DATEADD(mm,DATEDIFF(mm,0,SomeDate),0),120)
                      ELSE 'Total'
                      END
        ,MonthTotal = SUM(SomeAmount)
   FROM dbo.Demo01
  GROUP BY DATEDIFF(mm,0,SomeDate) WITH ROLLUP
  ORDER BY GROUPING(DATEDIFF(mm,0,SomeDate)), DATEDIFF(mm,0,SomeDate);
    SET STATISTICS TIME,IO OFF;
GO 2
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 20                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Add a non-clustered "covering" index and run the report again.
--      Then compare the very low number of pages read against those from above.
--      This DOES prove that a "duplicate" index can really help if you can't
--      move the LOBs "out of row".
--=================================================================================================
--===== Add the index
 CREATE INDEX IX_ByDate ON dbo.Demo01 (SomeDate)
        INCLUDE (SomeAmount)
;
GO
--===== Clear the "guns"
        CHECKPOINT;
   DBCC FREEPROCCACHE;
   DBCC DROPCLEANBUFFERS
;
GO
--===== Turn the timers on, run the report, turn the timers off.
    SET STATISTICS TIME,IO ON;
 SELECT  [YYYY-MM]  = CASE GROUPING(DATEDIFF(mm,0,SomeDate))
                      WHEN 0 THEN CONVERT(CHAR(7),DATEADD(mm,DATEDIFF(mm,0,SomeDate),0),120)
                      ELSE 'Total'
                      END
        ,MonthTotal = SUM(SomeAmount)
   FROM dbo.Demo01
  GROUP BY DATEDIFF(mm,0,SomeDate) WITH ROLLUP
  ORDER BY GROUPING(DATEDIFF(mm,0,SomeDate)), DATEDIFF(mm,0,SomeDate);
    SET STATISTICS TIME,IO OFF;
GO 2
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Drop the index we just created
   DROP INDEX IX_ByDate ON dbo.Demo01
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                   Page 24, 25 and 26                                  @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Set the table option for having LOBs "Out of Row".
--      It does nothing for the existing data.  The Page Count at the Leaf Level
--      of the Clustered Index is unchanged meaning no data has moved "out of row"
--=================================================================================================
--===== Set the option
   EXEC sp_tableoption 'dbo.Demo01', 'large value types out of row', 1
;
GO
--===== Update the existing data to get it to move "Out-of-Row"
     -- (In-Place Update - Values are updated to themselves)
     -- This can be tough on the Transaction Log file... but it's worth it!
 UPDATE dbo.Demo01
    SET Comment = Comment
;
GO
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                  Page 27 and 28                                       @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      MUST REBUILD the Index after the Move
--=================================================================================================

--===== REBUILD the index to recover the disk space.
     -- The first benefit of Out-of-Row LOBs is realized.
     -- People using the "Standard Edition" will love this.
    SET STATISTICS TIME,IO ON;
  ALTER INDEX PK_Demo01 ON dbo.Demo01 REBUILD;
    SET STATISTICS TIME,IO OFF;
GO
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo01')
;
GO
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo01');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 28                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Run the report after the move.
--=================================================================================================

--===== Clear the "guns"
        CHECKPOINT;
   DBCC FREEPROCCACHE;
   DBCC DROPCLEANBUFFERS
;
GO
--===== Turn the timers on, run the report, turn the timers off.
    SET STATISTICS TIME,IO ON;
 SELECT  [YYYY-MM]  = CASE GROUPING(DATEDIFF(mm,0,SomeDate))
                      WHEN 0 THEN CONVERT(CHAR(7),DATEADD(mm,DATEDIFF(mm,0,SomeDate),0),120)
                      ELSE 'Total'
                      END
        ,MonthTotal = SUM(SomeAmount)
   FROM dbo.Demo01
  GROUP BY DATEDIFF(mm,0,SomeDate) WITH ROLLUP
  ORDER BY GROUPING(DATEDIFF(mm,0,SomeDate)), DATEDIFF(mm,0,SomeDate);
    SET STATISTICS TIME,IO OFF;
GO 2

