--===== This is the Demo02 file

--=================================================================================================
--      The Demo01 table currently has 10 months of data in it.
--      The 10th month has been seriously fragmented by the addition of just 333 comments.
--      We'll rebuild it at 100% and use it as a baseline for our next experiment
--=================================================================================================
--===== Make sure we're using the corrrect demo database for this presentaiton.
    USE BlackArtsIM03
;
--===== Rebuild the index with a FillFactor to 100.
     -- We don't need to waste any space any more.
  ALTER INDEX PK_Demo01 ON dbo.Demo01 REBUILD WITH (FILLFACTOR = 100)
;
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                 Prep for Page 47                                      @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Demonstrate the full fix for an existing table.
--      Create and populate a typical table for this problem.
--      Populate 9 Months of data, just like before.
--      Note that there is no default on the Comment column at this point.
--=================================================================================================
        SET STATISTICS TIME,IO OFF
;
--===== If the test table already exists, drop it to make rerun in SSMS easier.
     IF OBJECT_ID('dbo.Demo02') IS NOT NULL
   DROP TABLE dbo.Demo02
;
GO
--===== Create the table (this represents and existing table)
 CREATE TABLE dbo.Demo02
        (
         SomeID         INT             IDENTITY(1,1)    --Fixed Width, 4 bytes
        ,SomeDate       DATETIME        NOT NULL         --Fixed Width, 8 bytes
        ,SomeAmount     DECIMAL(9,2)    NULL             --Fixed Width, 5 bytes
        ,OtherColumns   CHAR(100)       NULL DEFAULT 'X' --Represents 100 bytes of other fixed width columns
        ,Comment        VARCHAR(MAX)    NULL             --LOB (Variable Width)
        ,CONSTRAINT PK_Demo02 PRIMARY KEY CLUSTERED (SomeID)
               WITH (FILLFACTOR = 100)
        )
;
--===== Populate the table with test data (9 months with approximately 10K rows per month)
     -- (Minimally logged in BULK LOGGED/SIMPLE Recovery Models
     -- even with the Clustered Index in-place on 2008+)
     -- Comments will be anywhere from NULL to 10,764 bytes
     -- and the table will contain 9 months of data (Jan thru Sep 2019)
DECLARE  @StartDate DATETIME = 'Jan 2019' --Inclusive
        ,@EndDate   DATETIME = 'Oct 2019' --Exclusive
;
     -- Actual table population
   WITH cte AS
(
 SELECT TOP 90000
         SomeDate   = RAND(CHECKSUM(NEWID()))
                    * DATEDIFF(dd,@StartDate,@EndDate)+@StartDate
        ,SomeAmount = CONVERT(DECIMAL(9,2),RAND(CHECKSUM(NEWID()))*100)
        ,Comment    = NULLIF(REPLICATE(CONVERT(
                        VARCHAR(MAX),NEWID()),ABS(CHECKSUM(NEWID())%300
                      )),'')
   FROM      sys.all_columns ac1 --Creates a "Pseudo Cursor" row source
  CROSS JOIN sys.all_columns ac2 --to replace the "loop"
)
 INSERT INTO dbo.Demo02 WITH (TABLOCK) --Required for Minimal Logging.
        (SomeDate,SomeAmount,Comment)
 SELECT SomeDate,SomeAmount,Comment
   FROM cte
  ORDER BY SomeDate --Won't sort if not needed so always include it.
 OPTION (RECOMPILE) --Undocumented assurance for Minimal Logging 
                    --especially if variables present.
;
GO
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo02')
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@               More Prep for Page 47 (This was shown earlier on page 46)               @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Do the fix including the previously missing step of assigning a Default to the LOB.
--      Set the table option for having LOBs "Out of Row".
--      It does nothing for the existing data.  The Page Count at the Leaf Level
--      of the Clustered Index is unchanged meaning no data has moved "out of row".
--      Note that we DO add the DEFAULT to the Comment column prior to the the move to out-of-row.
--      This takes 00:00:37 to execute
--=================================================================================================
--===== Set the "Out of Row" table option
   EXEC sp_tableoption 'dbo.Demo02', 'large value types out of row', 1
;
--*************************************************************************************************
-- THIS IS THE FIX FOR FIXING "EXPANSIVE" OUT-OF-ROW UPDATES
--*************************************************************************************************
--===== Redefine the comments column to have a single space default,
     -- which will add the 24 byte pointer to new rows even if comments
     -- aren't added.
  ALTER TABLE dbo.Demo02
    ADD CONSTRAINT DF_Comment_As_Space DEFAULT ' ' FOR Comment;
;
--===== Update the existing data to get it to move "Out-of-Row"
 UPDATE dbo.Demo02
    SET Comment = ISNULL(Comment,' ') --ISNULL changes the existing NULL rows to the default
;
--===== Rebuild the index with a FillFactor to 100.
     -- We don't need to waste any space any more.
  ALTER INDEX PK_Demo02 ON dbo.Demo02 REBUILD WITH (FILLFACTOR = 100)
;
--===== Check the physical stats.
 SELECT * FROM dbo.PhysStats('dbo.Demo02')
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                               More Prep for Page 47                                   @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--=================================================================================================
--      Demonstrate the altered table as "Defragged by Default".
--      Populating the table and updating it no longer causes fragmentation.
--      Adding one month with no Comments, just like before.
--=================================================================================================
--===== Delete any rows for Oct 2019 (Mostly for retesing purposes).
DELETE FROM dbo.Demo02 
  WHERE SomeDate >= 'Oct 2019'
    AND SomeDate <  'Nov 2019'
;
GO
--===== Add 10K rows in Oct 2019 WITHOUT THE COMMENTS, just like we did before.
DECLARE  @StartDate DATETIME = 'Oct 2019' --Inclusive
        ,@EndDate   DATETIME = 'Nov 2019' --Exclusive
;
   WITH cte AS
(
 SELECT TOP 10000
         SomeDate   = RAND(CHECKSUM(NEWID()))
                    * DATEDIFF(dd,@StartDate,@EndDate)+@StartDate
        ,SomeAmount = CONVERT(DECIMAL(9,2),RAND(CHECKSUM(NEWID()))*100)

   FROM      sys.all_columns ac1 --Creates a "Pseudo Cursor" row source
  CROSS JOIN sys.all_columns ac2 --to replace the "loop"
)
 INSERT INTO dbo.Demo02 WITH (TABLOCK) --Required for Minimal Logging.
        (SomeDate,SomeAmount)
 SELECT SomeDate,SomeAmount
   FROM cte
  ORDER BY SomeDate --Won't sort if not needed so always include it.
 OPTION (RECOMPILE) --Undocumented assurance for Minimal Logging 
                    --especially if variables present.
;
GO
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo02');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 48                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--===== Now add the month's worth of Comments afterwards as we might do in real life
     -- just like we did before.
 UPDATE dbo.Demo02
    SET Comment    = NULLIF(REPLICATE(CONVERT(
                        VARCHAR(MAX),NEWID()),ABS(CHECKSUM(NEWID())%300
                      )),'')
  WHERE SomeDate   >= 'Oct 2019' --Inclusive
    AND SomeDate   <  'Nov 2019' --Exclusive
    AND SomeID % 30 = 0 --Only rows with IDs evenly divisible by 30
;
--===== Run an Index DNA to see what's up with Page Density
DECLARE @ObjectID INT = OBJECT_ID('dbo.Demo02');
   EXEC sp_IndexDNA @ObjectID, 1
;
GO
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--@@@@@                                      Page 49                                          @@@@@
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--===== Check the physical stats of both tables and compare the pages used.
     -- The result is that even with the Default, we're using less disk space for Demo02.
     -- Basically, we got "DEFRAGMENTED BY DEFAULT" for a cost of only 30 pages out of 73,308!!!
 SELECT * FROM dbo.PhysStats('dbo.Demo01');  --Has NO default for Comments
 SELECT * FROM dbo.PhysStats('dbo.Demo02');  --DOES have default for Comments
GO
;