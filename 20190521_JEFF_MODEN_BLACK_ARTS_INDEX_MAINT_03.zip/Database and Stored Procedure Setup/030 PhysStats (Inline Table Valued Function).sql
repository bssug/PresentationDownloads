    USE BlackArtsIM03;
GO
 CREATE FUNCTION dbo.PhysStats
/**********************************************************************************************************************
 Purpose:
 Given a 2 part user table name in the form of 'SchemaName.TableName', return a summary of what is available from the 
 systemfunction of sys.dm_db_index_physical_stats using the "DETAILED" option for all IN_ROW_DATA, LOB_DATA, and
 ROW_OVERFLOW_DATA page types.

 Note that the output is sorted by page type, index ID, and the level of the pages in the B-Tree.

 Usage Example:
 SELECT * FROM dbo.PhysStats('SchemaName.TableName')
;
 Programmer notes:
 1. This function must exist in the same database as the given table name.
 2. This function is a high performance iTVF (Inline Table Valued Function).
 3. This code will return an error if used against system views such as sys.objects.
 4. No reference to the table name or object_id is returned. Because the function requires the table name, it's 
    assumed that information is already available to the user.
 5. The generally accepted maximum number of bytes per page is 8,060.  While that is sort of true for user information,
    it's not true when it comes to total page size/row size. The number 8,096 is correct when it comes to actual page
    size for total page content associated with user information, which includes such things as the individual row 
    headers, etc.  For example, a table with a single INT column will actually have a row size of 11... 4 bytes for the
    INT and 7 bytes for the row header (which varies in size for other things), which is included for EVERY row in the
    table or index.

 Revision History:
 Rev 00 - 03 Mar 2019 - Jeff Moden
        - Initial creation and unit test
**********************************************************************************************************************/
--===== Define the I/0 for this function
        (@pTableName SYSNAME)
RETURNS TABLE AS --Cannot use WITH SCHEMABINDING against a system table
 RETURN
--===== Return the summarized physical stats information in table format for the given table.
 SELECT TOP 2147483647 --TOP is necessary for a sort within a function.
         SizeMB         = CONVERT(DECIMAL(9,1),page_count/128.0)
        ,IdxID          = index_id
        ,PageType       = alloc_unit_type_desc
        ,IdxLvl         = index_level
        ,FragPct        = CONVERT(DECIMAL(9,4),avg_fragmentation_in_percent)
        ,PageCnt        = page_count
        ,PageDensity    = CONVERT(DECIMAL(9,4),avg_page_space_used_in_percent)
        ,MinRecSize     = min_record_size_in_bytes
        ,AvgRecSize     = avg_record_size_in_bytes
        ,MaxRecSize     = max_record_size_in_bytes
        ,AvgRowsPerPage = ISNULL(8096/NULLIF(CONVERT(INT,avg_record_size_in_bytes),0),0) --See Programmer Note #5
        ,RecCnt         = record_count
   FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID(@pTableName),NULL,NULL,'DETAILED')
  ORDER BY PageType, IdxID, IdxLvl --ORDER BY not normally done in a function but is real handy for demo purposes.
;
GO