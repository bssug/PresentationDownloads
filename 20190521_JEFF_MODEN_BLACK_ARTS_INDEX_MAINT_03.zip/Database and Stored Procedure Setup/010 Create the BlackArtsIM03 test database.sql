--====================================================================================================================
--      Presets
--====================================================================================================================
--===== Move to a database that isn't going to be affected
    USE master
;
--===== Setup the evironment
    SET NOCOUNT ON
;
--===== Declare a variable to hold dynamic SQL
DECLARE @SQL VARCHAR(8000)
;
--====================================================================================================================
--      Conditionally drop the test database if it exists.
--      Note that we give the operator a warning and period of time to abort just to be safe
--====================================================================================================================
--===== If the test database already exists, unconditionally drop it.
        RAISERROR('Checking if the BlackArtsIM03 database exists...',0,0) WITH NOWAIT
;
     IF DB_ID('BlackArtsIM03') IS NOT NULL
  BEGIN
        --===== Give the operator the chance to abort dropping the database.
        SELECT [***** WARNING!!! THE BLACKARTSIM03 DATABASE ALREADY EXISTS! *****]
             = 'You have 20 seconds to manually abort by clicking the STOP icon.'
        ;
        RAISERROR('***** WARNING!!! THE BLACKARTSIM03 DATABASE ALREADY EXISTS! *****',0,0) WITH NOWAIT;
        RAISERROR('You have 20 seconds to manually abort by clicking the STOP icon.',0,0) WITH NOWAIT
        ;
        WAITFOR DELAY '00:00:20'
        ;
        --===== If we make it to here, unconditionally drop the database.
        SELECT @SQL = '
   EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''BlackArtsIM03'';
  ALTER DATABASE BlackArtsIM03 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
   DROP DATABASE BlackArtsIM03;'
        ;
        EXECUTE (@SQL);
        RAISERROR('BlackArtsIM03 database existed and has been dropped.',0,0) WITH NOWAIT
        ;
         SELECT [Continuing... see the "Messages" tab to monitor progress...]
              = 'Continuing... see the "Messages" tab to monitor progress...'
        ;
        RAISERROR('Continuing...',0,0) WITH NOWAIT
        ;
    END 
;
  PRINT REPLICATE('-',119)
;
--====================================================================================================================
--      Create and configure the test database for use.
--====================================================================================================================
        RAISERROR('Creating/configuring the test database...',0,0) WITH NOWAIT
;
--===== Create the test database
 CREATE DATABASE BlackArtsIM03
;
--===== Resize the files and growth for the test database
 SELECT @SQL = '
--===== Size the MDF file
  ALTER DATABASE BlackArtsIM03 
 MODIFY FILE
        (
         Name       = BlackArtsIM03
        ,SIZE       = 1000MB
        ,MAXSIZE    = UNLIMITED
        ,FILEGROWTH = 100MB
        )
;
--===== Size the LDF file
  ALTER DATABASE BlackArtsIM03
 MODIFY FILE
        (
         Name       = BlackArtsIM03_log
        ,SIZE       = 100MB
        ,MAXSIZE    = UNLIMITED
        ,FILEGROWTH = 100MB
        )
;
--===== Set the database to the SIMPLE Recovery Model to take
     -- advantage of "Minimal Logging" and Log File Auto-truncation.
  ALTER DATABASE BlackArtsIM03 SET RECOVERY SIMPLE WITH NO_WAIT
;
'
;
EXECUTE (@SQL)
;
 SELECT [Run complete. Database created using the SIMPLE Recovery Model.      .]
      = 'Don''t forget to create the sp_IndexDNA and PhyStats stored procedures.'
;
        RAISERROR('Run complete. Database created.',0,0) WITH NOWAIT;
        RAISERROR('Don''t forget to create the sp_IndexDNA and PhysStats stored procedures.',0,0) WITH NOWAIT
;
  PRINT REPLICATE('-',119)
;
GO
