#install.packages('mongolite')
library(mongolite)
#install.packages('ggplot2')
library(ggplot2)

#{r cosmos_db_connect}
mgo <- mongo(db = "wave", collection = "Sensor",  url="mongodb://...")

#print(mgo$info())

#{r count}
cnt = mgo$count()
print(cnt)

#display fields
#mgo$iterate()$one()

lastMin = Sys.time() - (60 * 1)
print(lastMin)

query = paste('{ "When" : { "$gte" : { "$date" : "', format(lastMin, "%Y-%m-%dT%H:%M:%SZ", 'UTC'), '"} } }', sep = "")
print(query)
#mongodb is periods
recent = mgo$find(query, field = '{ "When": true, "MachineName" : true, "Angles.Absolute.X" : true }' , limit = 100)
print(recent)

#R is $s
ggplot(recent, aes(x = When, y = Angles$Absolute$X)) +
    geom_line(aes(group = 1), size = 1.5, color = "red") +
    ylab("Angular Motion") +
    scale_x_datetime(date_labels = "%H:%M:%S") +
    ggtitle(paste("Since", lastMin)) +
    theme(axis.title.x = element_blank(), axis.text.y = element_text(color = "blue", size = 11, angle = 0, hjust = 1, vjust = 0),
      axis.text.x = element_text(color = "blue", size = 11, angle = 0, hjust = .5, vjust = .5),
      axis.title.y = element_text(size = 14),
      plot.title = element_text(size = 16, color = "purple", hjust = 0.5))
