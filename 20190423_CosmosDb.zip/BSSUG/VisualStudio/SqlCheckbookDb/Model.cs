﻿
using Microsoft.EntityFrameworkCore;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace SqlCheckbookDb
{
    public class CheckBookContext : DbContext
    {
        private const string Void = "VOID";

        public Payee VoidPayee { get { return Payees.Where(p => p.Name == Void).FirstOrDefault(); } }

        public DbSet<Bank> Banks { get; set; }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Payee> Payees { get; set; }
        public DbSet<Check> Checks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>();
            modelBuilder.Entity<Payee>()
                .HasIndex(p => new { p.Name });
            modelBuilder.Entity<Check>()
                .HasIndex(p => new { p.CheckId, p.CheckNunmber })
                .IsUnique();
            modelBuilder.Entity<Check>()
                .HasIndex(p => new { p.PayeeId });

            base.OnModelCreating(modelBuilder);
        }

        /// <summary>
        /// Ensure the database has my checking accounts
        /// </summary>
        public async Task<int> Seed()
        {
            var boa = await ensureBank("Bank Of America, NA", "F7CC0F065", "Baltimore, MD 21215", "01-133/220");
            var wells = await ensureBank("Wells Fargo Bank, NA", "4526BA50Q", "www.wellsgargo.com", "66-220/510");
            await ensureAccount("BOA Joint Checking", "John and Jane Doe", boa, "57C0A50A08", "Wheat", "100 West St.", "Baltimore, MD 21238", 3);
            await ensureAccount("BOA Business Checking", "John's Pizza", boa, "0DB6A276D4", "LightBlue", "100 West St.", "Baltimore, MD 21238", 3);
            await ensureAccount("Wells Fargo Business Checking", "John's Pizza, LLC", wells, "2C6B4970", "LightGreen", "100 West St.", "Baltimore, MD 21238", 1);
            await ensurePayee(Void, "none");
            return await SaveChangesAsync();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=...;Database=CheckBook;Trusted_Connection=True;");
        }


        /// <summary>
        /// Ensure a payee exists in the DB
        /// </summary>
        /// <param name="name">Name of the party</param>
        /// <returns></returns>
        private async Task<Payee> ensurePayee(
            string name,
            string addressLine1)
        {
            var payee = await Payees.Where(p => p.Name == name).FirstOrDefaultAsync();
            if (payee == null)
            {
                payee = new Payee()
                {
                    Name = name,
                };
                Payees.Add(payee);
            }
            payee.AddressLine1 = addressLine1;

            return payee;
        }

        /// <summary>
        /// Ensure an account exists. If not add it
        /// </summary>
        /// <param name="nickName"></param>
        /// <param name="aba"></param>
        /// <param name="accNumber"></param>
        private async Task<Bank> ensureBank(
            string name,
            string aba,
            string addressLine1,
            string addressLine2)
        {
            var bank = await Banks.Where(acc => acc.AbaRoutingNumber == aba).FirstOrDefaultAsync();
            if (bank == null)
            {
                bank = new Bank()
                {
                    AbaRoutingNumber = aba,
                };
                Banks.Add(bank);
            }
            bank.Name = name;
            bank.AbaRoutingNumber = aba;
            bank.BankAddressLine1 = addressLine1;
            bank.BankAddressLine2 = addressLine2;

            return bank;
        }

        /// <summary>
        /// Ensure an account exists. If not add it
        /// </summary>
        /// <param name="nickName"></param>
        /// <param name="aba"></param>
        /// <param name="accNumber"></param>
        private async Task<Account> ensureAccount(
            string nickName,
            string statementName,
            Bank bank, 
            string accNumber,
            string accountColor,
            string addressLine1,
            string addressLine2,
            int? checkPerPage)
        {
            var checkingAccount = await Accounts.Where(acc => acc.AccountNumber == accNumber).FirstOrDefaultAsync();
            if (checkingAccount == null)
            {
                checkingAccount = new Account()
                {
                    AccountNumber = accNumber,
                };
                Accounts.Add(checkingAccount);
            }
            checkingAccount.NickName = nickName;
            checkingAccount.StatementName = statementName;
            checkingAccount.Bank = bank;
            checkingAccount.ColorValue = accountColor.ToString();
            checkingAccount.AccountAddressLine1 = addressLine1;
            checkingAccount.AccountAddressLine2 = addressLine2;
            checkingAccount.CheckToPrintPerPage = checkPerPage;

            return checkingAccount;
        }

    }

    /// <summary>
    /// A banking institution
    /// </summary>
    public class Bank
    {
        [BsonIgnore]
        [Key]
        public int BankId { get; set; }

        [Required]
        [MaxLength(36)]
        public string Name { get; set; }

        [MaxLength(63)]
        public string BankAddressLine1 { get; set; }

        [MaxLength(63)]
        public string BankAddressLine2 { get; set; }

        [MaxLength(9), MinLength(9)]
        public string AbaRoutingNumber { get; set; }

        public override string ToString()
        {
            return $"{Name} ({AbaRoutingNumber})";
        }
    }

    /// <summary>
    /// A bank checking account
    /// </summary>
    public class Account
    {
        [BsonIgnore]
        [Key]
        public int AccountId { get; set; }

        [Required]
        public string NickName { get; set; }

        [Required]
        [MaxLength(36)]
        public string StatementName { get; set; }

        [MaxLength(127)]
        public string AccountAddressLine1 { get; set; }

        [MaxLength(127)]
        public string AccountAddressLine2 { get; set; }

        public string ColorValue { get; set; }

        [BsonIgnore]
        public int BankId { get; set; }

        /// <summary>
        /// The number of checks to print on a single page.
        /// NULL mean that checks are not printed from the register
        /// for this account
        /// </summary>
        public int? CheckToPrintPerPage { get; set; }

        [MaxLength(10)]
        public string AccountNumber { get; set; }

        [ForeignKey("BankId")]
        public virtual Bank Bank { get; set; }

    }

    /// <summary>
    /// A check payees
    /// </summary>
    public class Payee
    {
        [BsonIgnore]
        [Key]
        public int PayeeId { get; set; }

        [Required]
        public string Name { get; set; }

        public string SubName { get; set; }

        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }

        [DataType("decimal(5,0")]
        public decimal? ZipCode { get; set; }

        [DataType("decimal(4,0")]
        public decimal? ExtendedZipCode { get; set; }

        public override string ToString()
        {
            return Name;
        }

    }

    public enum CheckStates: int
    {
        /// <summary>
        /// Prepare the check for creation
        /// </summary>
        Pending = 0,

        /// <summary>
        /// The check is written, saved, but not printed
        /// </summary>
        Written = 1,

        /// <summary>
        /// The check is written, saved, but not printed
        /// and will be voided when printed
        /// </summary>
        WrittenPendingVoid = 2,

        /// <summary>
        /// The check is printed
        /// </summary>
        Printed = 3,

        /// <summary>
        /// The check has clear at the bank
        /// </summary>
        Cleared = 4,

        /// <summary>
        /// The check was voided before clearing
        /// </summary>
        Void = 5,
    }

    public class Check
    {
        [NotMapped] //EF
        [BsonId]    //MongoDb
        public Guid Id { get; set; }

        [BsonIgnore]
        [Key]
        public int CheckId { get; set; }

        [BsonIgnore]
        [Required]
        public int AccountId { get; set; }

        [BsonIgnore]
        [Required]
        public int PayeeId { get; set; }

        [Required]
        public DateTime Date { get; set; }

        [Required]
        public CheckStates State { get; set; }

        [Required]
        public decimal CheckNunmber { get; set; }

        [Required]
        [Column(TypeName = "Money")]
        public decimal Amount { get; set; }

        public string Memo { get; set; }

        [ForeignKey("PayeeId")]
        public virtual Payee Payee { get; set; }

        [ForeignKey("AccountId")]
        public virtual Account Account { get; set; }

    }
}

        