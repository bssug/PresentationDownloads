﻿using MongoDB.Driver;
using System;
using System.Linq;
using System.Security.Authentication;

namespace SqlCheckbookDb
{
    class Program
    {
        private const string DatabaseId = "testdb";
        private const string CollectionId = "Checkbook";

        private Check StoreWithEntityFrameworkToSqlServer()
        {
            using (var db = new CheckBookContext())
            {
                Console.WriteLine("Connecting to SQL Server");
                db.Database.EnsureCreated();
                var task = db.Seed();
                task.Wait();

                var account = db.Accounts.First();
                var amount = (DateTime.Now - new DateTime(2019, 1, 1)).TotalSeconds / 100;
                var newPayee = new Payee
                {
                    Name = "Fred Smith",
                };
                var newCheck = new Check
                {
                    Account = account,
                    Amount = Math.Round((decimal)amount, 2),
                    CheckNunmber = DateTime.Now.Millisecond,
                    Date = DateTime.Now,
                    Payee = newPayee,
                    State = CheckStates.Pending,
                    Memo = "Testing",
                };
                db.Payees.Add(newPayee);
                db.Checks.Add(newCheck);
                var changes = db.SaveChanges();
                Console.WriteLine($"{changes} Changes");
                Console.ReadLine();

                return newCheck;
            }
        }

        private void StoreWithMongoDbApiToCosmosDb(Check newCheck)
        {
            Console.WriteLine("Connecting to Cosmos DB with MongoDb protocol");
            newCheck.Memo = "MongoDB API testing";
            newCheck.Id = Guid.NewGuid();

            //connect to mongo DB
            string connectionString = GetEnvironmentVariable("MongoDb");
            var settings = MongoClientSettings.FromUrl(
              new MongoUrl(connectionString));
            settings.SslSettings =
              new SslSettings() { EnabledSslProtocols = SslProtocols.Tls12 };
            var mongoClient = new MongoClient(settings);

            //get the database and do some mappings
            var checkbook = mongoClient.GetDatabase(DatabaseId);

            var documentCollection = checkbook.GetCollection<Check>(CollectionId);
            documentCollection.InsertOne(newCheck);
            Console.WriteLine("Inserted with MongoDb API.");
            Console.ReadLine();
        }

        private void UpdateDocumentWithMongoDbApiToCosmosDb(Check clearedCheck)
        {
            Console.WriteLine("Connecting to Cosmos DB with MongoDb protocol");
            clearedCheck.State = CheckStates.Cleared;

            //connect to mongo DB
            string connectionString = GetEnvironmentVariable("MongoDb");
            var settings = MongoClientSettings.FromUrl(
              new MongoUrl(connectionString));
            settings.SslSettings =
              new SslSettings() { EnabledSslProtocols = SslProtocols.Tls12 };
            var mongoClient = new MongoClient(settings);

            //get the database and do some mappings
            var checkbook = mongoClient.GetDatabase(DatabaseId);

            var documentCollection = checkbook.GetCollection<Check>(CollectionId);

            var filter = Builders<Check>.Filter.Eq(c => c.Id, clearedCheck.Id);
            var update = Builders<Check>.Update.Set(c => c.State, clearedCheck.State);

            var result = documentCollection.UpdateOne(filter, update);
            Console.WriteLine($"Update with MongoDb API {result.ModifiedCount}.");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            var prg = new Program();
            try
            {
                var newCheck = prg.StoreWithEntityFrameworkToSqlServer();
                prg.StoreWithMongoDbApiToCosmosDb(newCheck);
                prg.UpdateDocumentWithMongoDbApiToCosmosDb(newCheck);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.ReadLine();
            }
        }

        private static string GetEnvironmentVariable(string name)
        {
            return Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }

    }
}
