import pymongo;
import pprint;

#connect to the server
print("started " + pymongo.version);
mongoClient = pymongo.MongoClient('mongodb://...');

#grab the wave database
db = mongoClient.wave;
pprint.pprint(db);
pprint.pprint(db.Sensor);

#grab  the sensor document collection
sensorDocs = db.Sensor;
print(sensorDocs.estimated_document_count());

 #find the most recent three documents and display them
cursor = sensorDocs.find().sort([('When', -1)]).limit(3)
for doc in cursor :
    pprint.pprint(doc);
