import pymongo;
import pprint;

#connect to the server
print("started " + pymongo.version);
mongoClient = pymongo.MongoClient('mongodb://...');

#check if the DB exits and access it
dblist = mongoClient.list_database_names()
pprint.pprint(dblist)
        
testDb = mongoClient["testdb"];

testCollection = testDb["testCollection"]
print(testCollection.estimated_document_count());

testDocument = { "name": "John", "address": "Highway 37" }

id = testCollection.insert_one(testDocument)
print(id)
doc = testCollection.find_one()
pprint.pprint(doc);
  

