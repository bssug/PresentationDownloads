import pymongo;
import pprint;

mongoClient = pymongo.MongoClient('mongodb://...');
db = mongoClient.wave;
sensorDocs = db.Sensor;

doc = sensorDocs.find(
    { "MachineName" : "MINWINPC" }
    ).limit(1)[0]
pprint.pprint(doc);
