import pymongo;
import pprint;

#connect to the server
print("started " + pymongo.version);
mongoClient = pymongo.MongoClient('mongodb://...');

#grab the wave database
db = mongoClient.wave;
pprint.pprint(db);
pprint.pprint(db.Sensor);

#grab  the sensor document collection
sensorDocs = db.Sensor;

#find the one document with a force mean greater than 0.1
# project only the machine name, when and fource
doc = sensorDocs.find_one(
    { "Force.Mean": { "$gt": 0.1 } },
    { "MachineName", "When", "Force"})
pprint.pprint(doc);
