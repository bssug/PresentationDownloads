--Stored procedure with 3 parameters

mno				1234	-> CL seek... stable -> NOT recompile
ln				
fn

mno, ln			1234 %t%  -> CL seek... stable -> NOT recompile
mno, fn			1234 %t%  -> CL seek... stable -> NOT recompile
ln, fn			two cases...
					selective enough case -> NOT recompile
						Kim% AND Tri%
					leading wildcards -> recompile

mno, ln, fn		1234 %t%  -> CL seek... stable -> NOT recompile